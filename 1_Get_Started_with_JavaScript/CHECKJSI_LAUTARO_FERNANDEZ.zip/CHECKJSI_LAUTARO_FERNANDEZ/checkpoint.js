const nombre = "Lautaro"; // String
const apellido = "Fernández"; // String
const dni = "35174222"; // String
var edad = 32; // Number
var estado_civil = "en pareja"; // String
var peso = 65.5; // Float
const tipo_sangre = "A"; // String
var estudiante = true; // Boolean
var trabaja = true; // Boolean
const celular = {
    marca: "LG",
    modelo: "K8",
    numero: "1160382014",
    liberado: true,
    caracteristicas: ["4g","camara","impermeable","HD","bluetooth"]
} // Object